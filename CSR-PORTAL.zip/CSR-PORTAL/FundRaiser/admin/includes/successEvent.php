<!DOCTYPE html>
<html>
<head>
	<title>Event Created Successfully</title>
	<style>
		.demo {
			text-align: center;
			margin-top: 20%;
			font-family: Helvetica;
			font-weight: bold;
			font-size: 30px;
			color: #707070;
		}
		.demo a {
			text-decoration: none;
		}
	</style>
</head>
<body>
	 <div class="demo">
	 	<center>
	 		Event has been created successfully!!!<br>
	 		<a href="../home.php">Click here to return to Homepage</a>
	 	</center>
	 </div>

</body>
</html>